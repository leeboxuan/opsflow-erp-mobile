export { useAuthRole } from './useAuthRole';
export type { AuthRole } from './useAuthRole';
