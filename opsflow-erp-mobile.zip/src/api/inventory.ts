import { apiClient, getErrorMessage } from './client';
import { InventoryItem } from './types';

/**
 * Search inventory items (by SKU, reference, or name).
 * GET /inventory/items?search=...
 */
export async function getInventoryItems(search?: string): Promise<InventoryItem[]> {
  try {
    const response = await apiClient.get<InventoryItem[] | { items: InventoryItem[] }>(
      '/inventory/items',
      search?.trim() ? { params: { search: search.trim() } } : {}
    );
    const data = response.data;
    if (Array.isArray(data)) return data;
    if (data && typeof data === 'object' && Array.isArray((data as any).items)) {
      return (data as any).items;
    }
    return [];
  } catch (e) {
    return [];
  }
}
