import { apiClient, getErrorMessage } from './client';
import { InventoryItem, InventoryBatch } from './types';

/**
 * Search inventory items (by SKU, reference, or name).
 * GET /inventory/items?search=...
 */
export async function getInventoryItems(search?: string): Promise<InventoryItem[]> {
  try {
    const response = await apiClient.get<InventoryItem[] | { items: InventoryItem[] }>(
      '/inventory/items',
      search?.trim() ? { params: { search: search.trim() } } : {}
    );
    const data = response.data;
    if (Array.isArray(data)) return data;
    if (data && typeof data === 'object' && Array.isArray((data as any).items)) {
      return (data as any).items;
    }
    return [];
  } catch (e) {
    return [];
  }
}

/**
 * Get batches (e.g. Open) for batch selection on line items.
 * GET /inventory/batches?status=Open
 */
export async function getBatches(status: string = 'Open'): Promise<InventoryBatch[]> {
  try {
    const response = await apiClient.get<InventoryBatch[] | { batches: InventoryBatch[]; items: InventoryBatch[] }>(
      '/inventory/batches',
      { params: { status } }
    );
    const data = response.data;
    if (Array.isArray(data)) return data;
    const obj = data as Record<string, unknown>;
    if (Array.isArray(obj?.batches)) return obj.batches as InventoryBatch[];
    if (Array.isArray(obj?.items)) return obj.items as InventoryBatch[];
    return [];
  } catch (e) {
    return [];
  }
}
